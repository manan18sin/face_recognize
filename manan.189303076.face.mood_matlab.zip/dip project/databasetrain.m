clc;
clear all;
close all;
%read image 
[fname,fpath]=uigetfile('.jpg','select file');
fname=strcat(fpath,fname);
im=imread(fname);


[width,height]=size(im);
if width>320
    im=imresize(im,[320,nan]);
end
if height>100
    im=imresize(im,[nan,320]);
end



%detect face
face_detector = vision.CascadeObjectDetector() ;
location_face=step(face_detector,im);
detected_image=insertShape(im,'Rectangle',location_face);
figure;
imshow(detected_image);
c=input('enter the class from 1 to 3');
%feature extraction
f=featurestatiscal(im);

%store data in database
try
    load db;
    f=[f c];
    db=[db;f];
    save db.mat db
catch
    db=[f c] ;
    save db.mat db
end    