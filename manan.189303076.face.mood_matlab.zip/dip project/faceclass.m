%test face for testing
clc;
clear all;
close all;
[fname,fpath]=uigetfile('.jpg','select file');
fname=strcat(fpath,fname);
im=imread(fname);
emotions=['angry','happy','neutral'];
%resize for easy use
[width,height]=size(im);
if width>320
    im=imresize(im,[320,nan]);
end
if height>320
    im=imresize(im,[nan,320]);
end


%detect face
face_detector = vision.CascadeObjectDetector() ;
location_face=step(face_detector,im);
detected_image=insertShape(im,'Rectangle',location_face);
figure; 
imshow(detected_image);
title('test face');


%find out which class it belong
ftest=featurestatiscal(im);
load db.mat
totaltrain=db(1,:);
ftrain=db(:,1:sizeof(totaltrain)-1);%all rows but 1 and 2 column
ctarin=db(:,sizeof(totaltrain));%only the last column
%matching the photo
for i=1:size(ftain,1)
    dist(i,:)=sum(abs(ftrain(i:1)-ftest));
end
Min=min(dist);
if(Min<3)
    m=find(dist==Min,1);
    det_class=ctrain(m);
    if det_class==1
        msgbox(strcat('detected class','happy'));
    elseif det_class==2
        msgbox(strcat('detected class','angry'));
    elseif det_class==3
        msgbox(strcat('detected class','neutral'));
    end    
else
    msgbox('this emotion not registered');
end    
   