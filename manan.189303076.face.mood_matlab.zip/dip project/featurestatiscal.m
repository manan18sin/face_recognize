function [f]=featurestatiscal(im)
%detect mouth
global J
mouthDetect = vision.CascadeObjectDetector('Mouth'); 
mouthDetect.MergeThreshold = 7 ; 
BB = step(mouthDetect,im); 
figure(2),imshow(im); 
for i = 1:size(BB,1) 
    rectangle('Position',BB(i,:),'LineWidth',3,'LineStyle','- ','EdgeColor','r'); 
end
for i = 1:size(BB,1)
    J= imcrop(im,BB(i,:)); 
    figure(3),subplot(6,6,i);imshow(J); 
end
J=double(J);
m=mean(mean(J));
s=std(std(J));

%eyes detect
eyesDetect = vision.CascadeObjectDetector('EyePairSmall'); 
eyesDetect.MergeThreshold = 7 ; 
BB = step(eyesDetect,im); 
figure(2),imshow(im); 
for i = 1:size(BB,1) 
    rectangle('Position',BB(i,:),'LineWidth',3,'LineStyle','- ','EdgeColor','r'); 
end
for i = 1:size(BB,1)
    J= imcrop(im,BB(i,:)); 
    figure(3),subplot(6,6,i);imshow(J); 
end
J=double(J);
em=mean(mean(J));
es=std(std(J));


f=[m s em es];
end